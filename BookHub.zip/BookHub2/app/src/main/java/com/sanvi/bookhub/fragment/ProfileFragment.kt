package com.sanvi.bookhub.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import com.sanvi.bookhub.R


class ProfileFragment : Fragment() {
    lateinit var etName:EditText
    lateinit var etEmail: EditText
    lateinit var etPhone:EditText
    lateinit var etAddress: EditText
    lateinit var btnSaveDetails:Button


    override fun onCreateView(

        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the layout for this com.sanvi.bookhub.fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }


}